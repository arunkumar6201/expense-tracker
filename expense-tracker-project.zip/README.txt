Expense Tracker App

How to run:
1. Install Node.js
2. Run:
   npm install
   npm start

Then open in browser.
